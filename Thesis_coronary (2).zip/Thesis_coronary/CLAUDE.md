# Thesis_coronary: content map (recreated 2026-11-13; gitignored, local only)

MSc thesis on coronary artery tree topology from CCTA (ImageCAS-X to CGPS). Build: `main.tex`.
Notes live as `%` header comments in each .tex file (dated entries, CHECK / CAREFUL / OPEN markers);
`\todonote{}` marks text still to be written.

## Files (content/)

- `frontmatter/`, `introduction.tex`, `background/` (anatomy, CCTA, disease, WSS = `sec:wss`)
- `litterature_review/` (`sec:lit-wss`, `sec:lit-measure`), `data/`
- `methodology/`: 01a tracer, 01b Medis, 02 population/outcome, 02b segment split (`sec:method-split`),
  03 prediction model (`sec:method-models`), 04 model size / feature selection (`sec:method-selection`),
  05 features (`sec:method-features`) with 05a-05d, 06 feature validity, 07 curvature FPCA.
  `bifurcation_plan.md` and `daugther_ration_plan.md` are the executed plans for 05b and 05c.
- `technical/` (cloglog GLMM `sec:tech-model`, sample size, FPCA), `results/`, `discussion.tex`,
  `conclusion.tex`, `appendix/bifurcation_point.tex` (`app:angle-origin`)

## The five features (code: `CGPS_data/thesis_final/`, README there)

| Feature | Definition | Rows | Module | Text |
|---|---|---|---|---|
| Curvature | mean Menger curvature, 5 mm chords, mm^-1 | all 9 segments | `curvature_feature.py` | 05a |
| Bifurcation angle | LAD-LCx; arccos(u_LAD . u_LCx), u = least-squares line through 11 points at 5-10 mm from O | pLAD, pLCx | `bifurcation_angle.py` | 05b |
| Daughter asymmetry | ln(D_LCx / D_LAD) | pLAD, pLCx | `daughter_ratio.py` | 05c |
| Finet's ratio | D_LM / (D_LAD + D_LCx) | pLAD, pLCx | `daughter_ratio.py` | 05c |
| Lumen taper | tau = -10 b, Theil-Sen slope of ln D vs arc length per segment; first 3 mm and 2 median radii around side branches dropped; missing < 10 mm kept | all 9 segments | `taper_feature.py` | 05d (to write) |

D = median area-equivalent diameter 2 sqrt(A / pi) of the tracer lumen contour: LAD and LCx over 5-10 mm
from O, LM over the first 2 mm from the ostium. O = where the LAD and LCx paths part. Secondary term (outside
the LR test): angle x asymmetry. Geometry block 5 df + 1.

## Fact ownership (state once, point elsewhere)

- Why shape disturbs flow: `sec:wss`; evidence for it: `sec:lit-wss`; why these five and why proximal rows only:
  `05_features.tex`; how they enter the model: `sec:method-models`.
- O and the 5-10 mm stretch are shared by 05b and 05c; keep them in step. Why O is approximate: appendix.
- Murray exponents (3, 2.39, 7/3) are no longer in 05c.

## Style rules used in the notes

British spelling; no "trunk"; reason before method; no sentence opening with "Because"; counterfactual rule
(rejected alternatives live in header notes, not in the text); "was associated", never "predicts", for
cross-sectional studies; "following" only where the method really is the cited one, else "adapted".

## Open items

- Tracer lumen-contour format unknown (`daughter_ratio.tracer_rings` raises): ratios and taper untested on data.
- `CGPS_data/progression_who_pooled.py` still uses the old Medis angle and has no ratios or new taper; model and
  chapter disagree until it calls `tree_angle`, `tree_ratios`, `tree_taper`.
- Zhang 2024 inflow result read from arXiv; Garcha 2025 full text not read; Finet's 0.678 not re-read.
- Ramus intermedius not separated by the tracer labels.
- `CGPS_data/thesis_final/README.md` still describes the angle as a mean over 5-10 mm and lacks `taper_feature.py`.
