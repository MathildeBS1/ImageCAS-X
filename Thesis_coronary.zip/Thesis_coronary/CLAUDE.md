# Thesis content map (`Thesis_coronary/`)

Read this before writing or editing any thesis text. It records what every chapter and section
already says, what each one leaves to another, and what later parts will say, so that new text
fills exactly its own gap and repeats nothing. Design decisions and writing rules are in the root
`CLAUDE.md` (not repeated here); the `thesis-style` skill holds the voice.

Map last rebuilt from the files on 2026-11-07. Note: `Thesis_coronary/` is not yet committed
(untracked), so this first version was built from the working files; from the first commit on,
it follows the committed state only.

## How to use this map

First, find the section you are writing in the chapter map below and read its "States", "Leaves
to" and "Open" lines. Subsequently, check the defined-once index and the fact-ownership index before
introducing any term, abbreviation, number or study: if it is already owned elsewhere, point back
to it (`Section~\ref{...}`) instead of restating it. Check what the following sections will say,
so nothing is pre-empted.

Keeping the map current: the map describes only **approved** text, and approved means
**committed**. Uncommitted drafts do not change the map. Each time a commit changes files under
`Thesis_coronary/`, update this file to what those committed files now contain: the entry of every
changed section (status, what it states, labels, cite keys, resolved or new open items), the
indexes, the unresolved cross-references, the inconsistency list and the "last rebuilt" date. Include
the map update in that commit, or in the next commit if the change was committed outside a session.
At the start of a writing session, check `git log -- Thesis_coronary/` against the date above and
catch up on any commits the map has not seen.

Status words: **full** = written prose; **notes** = header comments plus one `\todonote`, nothing
written; **stub** = template placeholder text; **empty** = heading only.

## Thesis spine

The question: does coronary geometry on a plaque-free baseline CCTA predict who develops plaque
about 10 years later, beyond the SCORE2 risk factors, in the Herlev–Østerbro (CGPS) serial cohort?

The argument runs: CAD is the leading cause of death and plaque collects where WSS is low, which
geometry determines (Introduction) → studies tie geometry to WSS, measure it inconsistently, and
never in a random, plaque-free population with follow-up (Literature Review) → anatomy, CAD,
the WSS mechanism and CCTA (Clinical Background) → the prediction model and FPCA as general methods
(Technical Background) → the CT volumes, visual reads and Medis data delivered (Data) → tracer,
Medis check, cohort and outcome, segments, model, budget, features, measurement properties, FPCA
(Methodology) → Results, Discussion, Conclusion (not written).

Chapter order (`main.tex`): Frontmatter → 1 Introduction → 2 Literature Review → 3 Clinical
Background → 4 Technical Background (input from `content/background.tex`, after Clinical) →
5 Data → 6 Methodology → 7 Results → 8 Discussion → 9 Conclusion → Appendix (AI declaration).
Note that the Literature Review comes **before** the Clinical Background, so the review is the
first place many terms meet the reader (see the defined-once index).

Chapter-wide rules already set by the files: no forward references in the Introduction, the
Literature Review or the Clinical Background (user, 2026-10-05); no opening paragraph or roadmap in
the Clinical and Technical Background (they start at their first section); Technical Background
holds only general methods in the present tense, every setting belongs in the Methodology.

---

## Frontmatter (`content/frontmatter/`)

- `abstract.tex` — **stub** ("Write the abstract here"). Write last.
- `preface.tex` — **stub** with [placeholders] for description, department, dates, programme.
- `acknowledgements.tex` — **stub**; also holds a placeholder "AI-Assisted Work Disclosure" that
  duplicates the appendix `aideclaration.tex`.
- `abbreviations.tex` — **stub list**: AI, CAD, CCTA, CT, DSC. DSC is a template leftover (no Dice
  anywhere); LM, LAD, LCx, RCA, PDA, PLA, WSS, SIS, SSS, ECG, HDL, GLMM, FPCA, SCORE2 are missing.

## 1 Introduction (`content/introduction.tex`, `ch:introduction`) — full, but OUTDATED design

States, paragraph by paragraph:
1. CVD is the leading cause of death, 19.2 million deaths in 2023; CAD nearly half
   (stark2025gbd). CAD = plaque in coronary walls; narrows, can rupture → clot → heart attack
   (libby2019atherosclerosis).
2. Plaque is uneven along the tree although risk factors reach every segment; it collects where
   wall shear stress (named here in words, "drag of the blood flow") is low or oscillating
   (chatzizisis2007ess); low mainly on the outer wall after a bifurcation and the inner wall of a
   bend (asakura1990flow); geometry can be measured from an image, shear cannot.
3. Geometry varies between individuals (temov2016bifurcation), so predisposition may depend on
   anatomy; standard risk assessment combines age, sex, smoking, blood pressure, cholesterol in one
   score (score2_2021).
4. Whether geometry adds to such a score is unknown: geometry defined inconsistently
   (cui2017bifurcation, kashyap2022tortuosity); mostly measured in referred patients with plaque
   already present, so geometry may be consequence not cause (han2022plaque).
5. Aim and design: CGPS random population sample, CCTA for research (fuchs2023cgps), rescanned 10
   years later. **Outdated here**: "two stages" — a pipeline that segments the tree, labels vessels
   and computes angles, radius ratios, curvature; then "a logistic regression on summary features
   and a transformer that reads the full curvature profile", "fitted separately for each coronary
   artery", "new plaque". A `% TODO` on the baseline model remains.
6. Closing: workflow at population scale; what a positive or a null result would mean.

Defines in prose: CAD, CGPS, CCTA. Header comment: evidence cut from here is owed to the Literature
Review (Temov 196 patients and 35.5–178° LM angle; Glagov 136 hearts, ~40% before narrowing).

Must be rewritten to the current design (root `CLAUDE.md`): one pooled segment-level cloglog GLMM
(to be confirmed the week of 2026-11-09), in-house tracer (not own segmentation), five features
(curvature, taper, LM angle, LM→LAD and LM→LCx ratios), outcome "incident coronary plaque" /
"developed plaque", one LR test of the geometry block. No transformer, no per-artery models.

## 2 Literature Review (`content/litterature_review.tex` → `litterature_review/`, `ch:literature`)

`00_chapter_intro.tex` — chapter heading only, **no opening paragraph**. Long header comment holds
the chapter rules: author and year as subject, `\cite` after the year, no numbers in prose (cohort
sizes only in the table), no concept explanations, no em dashes, synthesis only when every element
is cited, `shen2026geometry` never cited anywhere in the thesis, CAD and CCTA assumed defined in the
Introduction. TODO: search statement (databases, window, date, inclusion criterion, exclusion
reasons). Still-owed sources listed there (Chen 2024, Lee 2024, CArTI, Good 2026, EMERALD, PROSPECT,
calcium scoring, Wu 2019, hampe2024gnn, taylor2024murray).

`01_geometry_wss.tex` — §Coronary Geometry and Wall Shear Stress (`sec:lit-wss`), full.
States: Asakura and Karino 1990 autopsy (plaque at bifurcations and bends); van der Giessen 2009
(outer walls of bifurcations in living patients, low WSS inferred, not computed) — **defines WSS**
("low wall shear stress (WSS)"); Kashyap 2022 (LM bifurcation, CAD-free CCTA, CFD; average curvature
the tortuosity measure most related to low WSS, significant but weak); Zhang 2024 (whole left trees,
public CCTA; curvature separated stenosed from stenosis-free trees at whole-tree level and between
bifurcations, not at them; low-WSS area only moderate vs severe); Garcha and Grande Gutiérrez 2025
(synthetic trees; low-WSS area grows with unequal LAD/LCX diameters, which also strengthens angle and
bending effects) — **defines LAD and LCX** here; Griffo 2026 (GNN estimates WSS from shape, agrees
with CFD; culprit lesion identified equally, moderately). Synthesis: shape decides where WSS is low.

`02_quantifying_geometry.tex` — §Quantifying Coronary Geometry (`sec:lit-measure`), full.
States: measure choice decides whether a relation is found. Cui 2017 (three LM angles; only LAD–LCX
angle wider with stenosis). Tortuosity disagreement in direction: Groves 2009 (visual, severe
tortuosity → less CAD), Li 2011 (bend count, less CAD, borderline; no outcome difference),
Tello Ayala 2026 (RCA turning-angle profile on angiograms, more tortuosity with CAD; transformer on
the profile better than the mean). Studies looked at RCA or left tree alone → whole tree needed.
Bransby 2026 (public CCTA re-annotated, segmentation benchmark; best method near but below
inter-annotator agreement).

`03_geometry_risk.tex` — §Geometry and Risk of Coronary Disease (`sec:lit-risk`), full + table
`tab:literature`. States: need geometry before plaque and a later scan; remodelling
(glagov1987remodeling). Sakellarios 2017 (repeated CCTA, established disease, WSS with daughter
branch). Han 2022 (ACS cases vs controls; culprit lesions nearer ostium and at bifurcations, but
events within weeks). Tommasino 2024 (1 year, wide LM angle → proximal LAD progression, many with
disease already). Won 2022 PARADIGM (plaque-free registry, rescanned, risk factors but no geometry).
Bergström 2021 SCAPIS (random sample, single scan). **Gap stated once here**: no study combined
automated whole-tree measurement with follow-up to plaque in a random population. Table: Zhang
2024, Li 2011, Tello Ayala 2026, Han 2022 with cohort sizes. Uses "new plaque" (twice, also in the
caption): should become "incident coronary plaque" / "developed plaque".

Leaves to others: the WSS mechanism (Clinical Background `sec:wss`); measure definitions (Methods).

## 3 Clinical Background (`content/background.tex` → `background/`, `ch:clinical`)

`chapter_intro.tex` — heading only. Header comment still says the outcome is "new plaque in a
healthy tree" and lists figures to upload (`wss_schematic.pdf`, `rq_curvature.pdf`).

`heart_anatomy.tex` — §The coronary circulation (`sec:circulation`), full. States: four chambers
(RA, LA, RV, LV), two pumps in series, aorta; myocardium supplied by coronary arteries from the aorta
above the aortic valve; **defines ostium, proximal, distal**. Figures `fig:heart-chambers`,
`fig:coronary-arteries` (one float).
- §§The coronary arterial tree (`sec:tree`): LM → LAD (anterior interventricular groove) and LCX
  (left AV groove); diagonals from the LAD, obtuse marginals from the LCX; RCA (right AV groove) →
  PDA and PLA. Defines LM, LAD, LCX, RCA, PDA, PLA (again, after the review).
- §§Coronary dominance (`sec:dominance`): crux; right/left/codominant; right 87–96%
  (ihdayhid2021ethnic); proximal RCA 3.9 vs 2.8 mm and LCX 3.4 vs 4.2 mm by dominance
  (dodge1992diameter). Ends: "every population statistic in this thesis is stratified by dominance"
  — conflicts with the model, where dominance is a base-model term; reconcile.

`disease_and_risk.tex` — §Coronary artery disease (`sec:disease`), full. Defines CAD (again),
atherosclerosis, plaque, endothelium, lumen, ischemia, thrombus, myocardial infarction. Two
mechanisms: gradual narrowing → ischemia (duncker2015regulation); cap rupture → thrombus
(libby2019atherosclerosis, rampidis2022geometry). Figure `fig:atherosclerosis`. No risk factors
and no calcium score despite the file name.

`wall_shear_stress.tex` — §Wall shear stress and plaque formation (`sec:wss`), full. Defines WSS
(again) and oscillatory WSS; plaque where WSS is low/oscillatory (chatzizisis2007ess,
samady2011wss, yamamoto2017ess); high WSS harmful only to existing narrowing plaque. Endothelium
mechanism: nitric oxide vs leaky, inflamed (chiu2011disturbed, davies2009shear). Bend: symmetric
profile in a straight tube, inertia carries fast blood outward, low WSS on the inner wall
(ku1997blood, dean1927curved, qiu2000compliant: inner wall about half the outer); defines disturbed
flow. Bifurcation: flow divider (high WSS, spared) vs lateral walls (disturbed); extent set by the
side-branch flow share (antoniadis2015bifurcation, zarins1983carotid, asakura1990flow,
vandergiessen2009bifurcation, nakazawa2010pathological). References `fig:wss-sites`, which does not
exist. No thresholds in Pa, no Poiseuille/R³ law (cut 2026-10-07); taper's WSS ∝ 1/r³ rationale is
owned by Methods `05d_taper`. Header: griffo2026wss must never be upgraded to "predicts plaque".

`ccta.tex` — §Coronary CT angiography (`sec:ccta`), full but ends abruptly after the voxel
sentence. Defines CCTA (again), contrast agent, ECG gating, mid-diastole reconstruction, heart-rate
lowering, voxel (knuuti2019esc, abbara2016scct). Header says resolution claims and "our 0.5 mm
grid" were added, but they are not in the text: the resolution part is missing or was cut.

## 4 Technical Background (`content/technical/`, `ch:technical`)

`00_chapter_intro.tex` — heading only; header lists sections and the rule (general methods only).
Added predictive value (C, calibration, Brier, log loss, NRI/IDI, internal validation) and sample
size (Riley criteria) are **deliberately not written** until the model is confirmed (week of
2026-11-09); drafts in `thesis/technical_background/03*.tex` and git `e4eb857`.

`01_prediction_model.tex` — §Prediction Model (`sec:tech-model`), **notes**. The one file that
describes the model. Will hold: risk prediction models (linear predictor, link), published score vs
developed model, SCORE2, recalibration steps (in-the-large, logistic, revision, refitting), the
mis-weighting hazard of a recalibrated base; if the cloglog GLMM is confirmed: clustered binary
outcomes, cloglog link and hazard ratios, length as offset or free term, random intercept as frailty,
MHR, Gauss–Hermite fitting, LR test of a block, pooling segment risks into a person risk and why
b = 0 is miscalibrated. Methods notes still point at old labels (`sec:tech-segment-glmm`,
`sec:tech-aggregation`, `sec:tech-recalibration`, `eq:tech-lr`, `sec:tech-added-value`,
`sec:tech-sample-size`, `sec:tech-internal-validation`) in comments; choose the final labels when
this is written.

`02_fpca.tex` — §Functional Principal Component Analysis (`sec:tech-fpca`), full. States: FPCA as
dimension reduction for curves (ramsay2005fda, wang2016fda); common domain t ∈ [0,1]; mean,
covariance (`eq:tech-fpca-cov`), eigenproblem (`eq:tech-fpca-eigen`), scores (`eq:tech-fpca-score`),
Karhunen–Loève truncation (`eq:tech-fpca-kl`), FVE (`eq:tech-fpca-fve`), modes of variation
(`eq:tech-fpca-mode`, jones1992displaying); no established rule for K; sign arbitrary; FPCA is
outcome-blind, low-variance components may carry risk. Defines curvature in words ("inverse radius
of the best-fitting circle").
- §§Computation on a Grid (`sec:tech-fpca-grid`): discrete form = PCA via SVD, scaling factors
  (`eq:tech-fpca-grid`), warmenhoven2021pca R² = 0.99.
- §§Registration: Amplitude and Phase (`sec:tech-fpca-registration`): phase vs amplitude, warping
  (marron2015amplitude); Sangalli 2009 AneuRisk example (65 patients, 33.4% / 18.2%, 21.5% error);
  mapping each segment to [0,1] is a linear warp; a shifted bend can read as a sharper bend.
Notation taken: x_i(t), μ, Γ, φ_k, λ_k, ξ_ik, t_g, G, D, d_i, v_k, w, α. Leaves to Methods: grid
size, interpolation, K rule, segments analysed, sign convention, software.

## 5 Data (`content/data.tex` → `data/`, `ch:data`)

`00_chapter_intro.tex` — opening paragraph + `tab:data-overview`, full. Three data sets: baseline CT
volumes (→ tracer and features; [n] scans), visual analysis at baseline and follow-up (→ cohort and
outcome; 1,801), Medis centerlines and contours (→ tracer reference; 600 / [n]). Defines CCTA again
(and SIS, SSS only in the table).

`01_ct_volumes.tex` — §Study Population and CT Volumes (`sec:data-cohort`), full. CGPS described
("referred to in this thesis as Herlev–Østerbro"), random from the Danish Civil Registration System;
1,801 participants, median follow-up [..] years (IQR [..]); non-contrast ECG-gated calcium scan +
CCTA at each visit; only baseline CCTA analysed; follow-up used through its visual read. Open:
volume count, scanner, kV, contrast, voxel size, kernel. Leaves cohort criteria to
`sec:method-population`.

`02_visual_analysis.tex` — §Visual Analysis and Patient Characteristics (`sec:data-plaque-location`),
full. All BL and FU scans read; per segment of 17: stenosis grade (none, minimal, mild, moderate,
severe, occlusion), plaque type, high-risk features, evaluability; **defines SIS and SSS**; unread
segments filled with none, separate read flag, all 1,801 BL scans read. SCORE2 factors recorded at
both visits (score2_2021). Open: who read the scans and how. The label name is historical (no plaque
location here; that moved to `sec:results-cohort`).

`03_medis_reference.tex` — §Medis Centerlines and Contours (`sec:data-medis`), full. 600 centerline
trees labelled by segment; 3,049 lumen and outer-wall contour segments, plaque segments only; all
600 linked in BL and FU; 599 with plaque at baseline, fewer than five plaque-free; 599 of 724 with
plaque have a tree (82.7%); 120 of the other 125 flagged finished, so likely lost in delivery;
similar plaque location, extent and worst grade. Open: how made, selection criterion, contour scan
count, completeness of LAD/LCx/RCA. Leaves all use of Medis to `sec:method-medis`.

## 6 Methodology (`content/methods.tex` → `methodology/`, `ch:methodology`)

`00_chapter_intro.tex` — full: nine-stage numbered opener (the one allowed inline list) pointing to
`fig:method-overview` (figure not made). Stages: (1) tracer, (2) Medis comparison, (3) cohort and
outcome, (4) segments, (5) model and CV, (6) parameter budget and feature choice, (7) features,
(8) measurement properties, (9) FPCA. Keep it in step with the sections below.

`01a_inhouse_tracker.tex` — §Coronary Centerline and Lumen Extraction (`sec:method-tracer`), full
but minimal: tracer applied to all baseline scans, developed and run by Kit Mills Bransby, described
only to show the pipeline. `\clarify` with an `enumerate` (question for Kit: description, name).
Not in it, compared with `thesis/`: the question whether centerlines are smoothed before output,
which `05a_curvature` depends on. Root `CLAUDE.md`: the tracer predicts the next centerline step
together with the lumen contour per step.

`01b_medis_reference.tex` — §Medis Reference as validation for the in house tracer output
(`sec:method-medis`), full. No ground truth → indirect estimate against Medis centerlines and
semi-manual contours; outside the plaque-free cohort; Medis labels by segment, tracer by artery →
Medis proximal/mid/distal collapsed into one full artery; only LAD, LCx, RCA.
- §§Agreement Between the Tracer and Medis (`sec:method-medis-agreement`): agreement on features,
  not points; tracer mapped into Medis coordinates, paired by participant and label; centerline
  features on the full artery, lumen features only between the first and last Medis contour
  (schaap2009cat08). Open: how Medis data were made; coordinate frames. The `thesis/` version also
  has the subsection label `sec:method-medis-arteries`, which this one lacks. Limitations (single
  reader, plaque-only reference, shared imaging errors) belong in the Discussion.

`02_population_outcome.tex` — §Study Cohort and Outcome (`sec:method-population`), full. Cohort =
SIS 0 at baseline, minus insufficient image quality ([criterion]); **defines incident coronary
plaque** (segment: minimal or worse; participant: plaque in ≥1 analysed segment); sensitivity
outcome mild or worse. `\clarify`: the outcome could still change. Counts go to
`sec:results-cohort`. Does not repeat the Data chapter.

`02b_segment_split.tex` — §Analysed Arteries and Segments (**no label**), full.
- §§Choice of Arteries (`sec:method-population-arteries`): LAD, LCx, RCA for outcome and features;
  present in every heart (side branches vary with dominance, `sec:dominance`); voxel-error argument
  with [..] blanks (dodge1992diameter); LM left out (literature relates the LM angle to LAD/LCx
  disease); plaque only in LM or a side branch counted as no outcome; discussion section on this
  misclassification owed.
- §§Division into Segments (`sec:method-split`): WSS is local → features at the outcome's
  resolution; proximal/mid/distal → nine segments (`fig:method-segments`, figure missing); landmark
  method, fixed fraction where no branch; full rules in `sec:app-split` (appendix not in the
  submission). The sentence naming the landmark branches seems to be missing ("no such branch").
- §§Validation of the Division (`sec:method-split-validation`): Medis contours projected onto the
  divided tracer artery; majority segment not graded plaque at baseline = miss; miss rate in
  `sec:results-cohort`.

`03_prediction_model.tex` — §Prediction Model (`sec:method-models`), §§Cross-Validation
(`sec:method-cv`), **notes**: pooled cloglog GLMM settings, base and extended model, LR test,
estimated measures, descriptive "where" read-out, person-level stratified folds. All settings come
from `progression_who_pooled.py`, not yet in `thesis_final/`.

`04_model_size.tex` — §Parameter Budget and Feature Selection (`sec:method-size`), §§Parameter
Budget (`sec:method-size-budget`), §§Selection of Geometric Features (`sec:method-selection`),
**notes**. Outcome-blind budget (Riley, S = 0.9, C = 0.70, also 0.65/0.75), df table; selection
prose: candidates set aside for weak support, CCTA measurement error, or overlap; five retained.
Honesty check: "prioritised", not "ranked".

`05_features.tex` — §Geometric Features (`sec:method-features`), **notes**, inputs:
- `05a_curvature.tex` §§Turning-angle curvature (`sec:method-curvature`), notes: 5 mm chords, atan2
  (`eq:method-turn`), profile κ = θ/ℓ (`eq:method-profile`, used by 07), arc-length mean T_s
  (`eq:method-tl`). Code: `thesis_final/turning_feature.py`.
- `05b_bifurcation_angle.tex` §§Bifurcation Angle (`sec:method-angle`), notes; no final code.
- `05c_daughter_ratio.tex` §§Daughter Ratio (`sec:method-ratio`), notes; ratios vs Huo–Kassab
  deviation undecided; owns Murray, 2.39 (taylor2024murray) and 7/3 (huo2012scaling).
- `05d_taper.tex` §§Lumen Taper (`sec:method-taper`), notes; owns the WSS = 4μQ/(πr³) rationale and
  the normal taper size (0.25 mm per 10 mm); per-artery vs per-segment unresolved.

`06_feature_validity.tex` — §Measurement Properties (`sec:method-validity`), **notes**, with
§§Technical Accuracy on Synthetic Shapes (`sec:method-validity-accuracy`), §§Definitional Choices
(`sec:method-validity-definitions`, `sec:method-validity-sensitivity`), §§Construct Validity
(`sec:method-validity-groups`, `sec:method-validity-evidence`), §§Variance Explained by Known Risk
Factors (`sec:method-validity-split`), §§Decision Rules (`sec:method-validity-reading`). The
subsections are empty headings. Medis deliberately not part of it.

`07_curvature_fpca.tex` — §Secondary Analysis of Curvature Shape (`sec:method-fpca`), **notes**:
pLAD and mLAD only, 50-point grid, SVD, no registration, K rule open, per-segment descriptive
cloglog. Relies on `sec:tech-fpca` (full) for every general definition.

## 7 Results (`content/results.tex`, `ch:results`)

Titled "Experiments and Results". Only `results/baseline.tex`: §Baseline segmentation
(`sec:baseline`), **stub** from the template ("week 7 figure goes here"); unrelated to this thesis.
Expected sections referenced from elsewhere: `sec:results-cohort` (cohort flowchart, counts, where
incident plaque developed, segment-division miss rate); `results/01_feature_validity` (from 06 notes).

## 8 Discussion (`content/discussion.tex`, `ch:discussion`) — empty

Headings §Limitations, §Future work. Already promised to it: misclassification of LM/side-branch-only
plaque (02b); Medis limitations (01b); repeatability not assessable
(`sec:disc-validity-repeatability`, 06 notes).

## 9 Conclusion (`content/conclusion.tex`, `ch:conclusion`) — empty

## Appendix

`aideclaration.tex` — "Use of generative AI", full (one paragraph). Expected but missing:
`sec:app-split` (segment division details) and `sec:app-validity` (feature validity details).

---

## Defined-once index (where each term is first defined, in reading order)

| Term | First defined | Also (re)defined in — remove or turn into a pointer |
|---|---|---|
| CAD | Introduction ¶1 | Clinical `sec:disease` |
| CCTA | Introduction ¶5 | Clinical `sec:ccta`; Data chapter intro |
| CGPS / Herlev–Østerbro | Introduction ¶5 (CGPS) | Data `sec:data-cohort` (both names) |
| Wall shear stress | Introduction ¶2 (in words) | Lit `sec:lit-wss` (abbrev. WSS); Clinical `sec:wss` |
| LAD, LCX | Lit `sec:lit-wss` (Garcha) | Clinical `sec:tree` |
| LM, RCA, PDA, PLA | Clinical `sec:tree` | Methods 02b (LAD/LCx/RCA, LM again) |
| Ostium, proximal, distal | Clinical `sec:circulation` | — |
| Dominance, crux | Clinical `sec:dominance` | — |
| Plaque, endothelium, lumen, ischemia, thrombus, MI | Clinical `sec:disease` | — |
| Oscillatory WSS, disturbed flow, flow divider, lateral wall | Clinical `sec:wss` | — |
| Voxel, ECG gating | Clinical `sec:ccta` | ECG again in Data `sec:data-cohort` |
| Curvature (inverse radius) | Technical `sec:tech-fpca` | Methods 05a (turning angle) |
| FPCA and its quantities | Technical `sec:tech-fpca` | — |
| SIS, SSS, stenosis grades | Data `sec:data-plaque-location` | Data intro table |
| SCORE2 factors | Introduction ¶3 (in words) | Data `sec:data-plaque-location` |
| Incident coronary plaque | Methods `sec:method-population` | — (the formal definition; elsewhere write "developed plaque") |
| Artery vs segment | Methods `sec:method-split` | — |

Spelling clash: the Literature Review and Clinical Background write **LCX**, the Data and Methods
chapters **LCx**; pick one.

## Fact ownership (state once, point back elsewhere)

- 19.2 million CVD deaths, CAD nearly half → Introduction.
- Right dominance 87–96%; RCA/LCX diameters by dominance → `sec:dominance`.
- 1,801 participants; all BL scans read → Data (`sec:data-cohort`, `sec:data-plaque-location`).
- Follow-up interval (median, IQR) → `sec:data-cohort` (blank).
- 600 Medis trees, 3,049 contours, 599/724 (82.7%), 120 of 125 finished → `sec:data-medis`.
- Clean-cohort size, image-quality exclusions, events, plaque per artery, 93.6% (452/483) of those
  who developed plaque have it in LAD/LCx/RCA, segment miss rate → `sec:results-cohort` (not written).
- Outcome definition and sensitivity outcome → `sec:method-population`.
- Kashyap: average curvature most related to low WSS, weak → Literature (`sec:lit-wss`); Methods
  05a may only point back ("although weakly").
- Measures disagree on direction (Groves, Li, Tello Ayala); Cui's angle choice → `sec:lit-measure`.
- The research gap → end of `sec:lit-risk` only.
- WSS mechanism (endothelium, bend, bifurcation) → `sec:wss`.
- Scaling-law exponents (Murray 3, 2.39, 7/3) → Methods 05c; WSS ∝ 1/r³ for taper → Methods 05d.
- FPCA definitions, grid scaling, registration hazard → `sec:tech-fpca`; settings → Methods 07.
- Tracer authorship (Kit Mills Bransby) → `sec:method-tracer`.

## Citation map (cite key → where cited)

Cited in more than one chapter: asakura1990flow (Intro, Lit 01, Clinical WSS); chatzizisis2007ess
(Intro, Clinical WSS); cui2017bifurcation (Intro, Lit 02); dodge1992diameter (Clinical dominance,
Methods 02b); garcha2025sensitivity (Lit 01, 02); han2022plaque (Intro, Lit 03);
kashyap2022tortuosity (Intro, Lit 01, 02); libby2019atherosclerosis (Intro, Clinical CAD);
score2_2021 (Intro, Data 02); vandergiessen2009bifurcation (Lit 01, Clinical WSS); zhang2024curvature
(Lit 01, 02).

Single chapter only — Introduction: stark2025gbd, temov2016bifurcation, fuchs2023cgps.
Literature: griffo2026wss, groves2009tortuosity, li2011tortuosity, telloayala2026tortuosity,
bransby2026imagecasx, glagov1987remodeling, sakellarios2017bifurcation, tommasino2024clap,
won2022paradigm, bergstrom2021scapis. Clinical: shah2009heart, weinhaus2024anatomy, devos2024coronary,
obrien2007anatomy, allwork1987applied, ihdayhid2021ethnic, duncker2015regulation,
rampidis2022geometry, samady2011wss, yamamoto2017ess, bajraktari2021highwss, davies2009shear,
chiu2011disturbed, ku1997blood, dean1927curved, qiu2000compliant, zarins1983carotid,
antoniadis2015bifurcation, nakazawa2010pathological, knuuti2019esc, abbara2016scct. Technical:
ramsay2005fda, wang2016fda, jones1992displaying, warmenhoven2021pca, marron2015amplitude,
sangalli2009aneurisk. Methods: schaap2009cat08.

Rules from the files: every study the Introduction cites must be discussed in the Literature
Review — temov2016bifurcation is cited in the Introduction but not discussed there (its evidence is
"owed" to the review). Never cite shen2026geometry. Studies from the review return in the Methods
only as citations inside a reason. Notes-only Methods files will add, among others:
vanzandwijk2019curvature, malek1999shear, medranogracia2016atlas, taylor2024murray, huo2012scaling,
finet2008fractal, gharleghi2024leftmain, mokkink2010cosmin, kessler2015qib, raunig2015qib,
lakens2017equivalence and others; check each is in `refs.bib` before use.

## Cross-references not yet resolved

- `fig:method-overview` (Methods 00) — overview figure not made.
- `fig:method-segments` (Methods 02b) — the figure exists in `thesis/methodology/02b_segment_split.tex`
  and `segment_selection_schematic.pdf` but was not taken over.
- `fig:wss-sites` (Clinical WSS) — no figure; header mentions a Shen 2026 crop, but Shen is never to
  be cited.
- `sec:app-split` (Methods 02b) — appendix not in the submission.
- `sec:results-cohort` (Methods 02, 02b; Data 02 comment) — Results section not written.
- Methods 02b's `Section~[..]` for the misclassification discussion.

## Known inconsistencies to resolve (listed, not fixed)

- Introduction ¶5 describes an obsolete design (own segmentation pipeline, logistic regression +
  transformer, per-artery models, "new plaque").
- "new plaque" also in Literature 03 (prose and table caption) and the Clinical chapter's header.
- Dominance: "every population statistic … stratified by dominance" (`sec:dominance`) vs dominance
  as a base-model covariate (Methods 03 notes).
- `ccta.tex` ends mid-section; the resolution paragraph its header describes is missing.
- `01a_inhouse_tracker.tex`: `enumerate` inside `\clarify`; smoothing question missing.
- `01b_medis_reference.tex`: header still points to `technical_background/07_agreement.tex`
  (retired); a bold **proximal**; a stray `Medis: \clarify{...}` line.
- `02b_segment_split.tex`: section has no label; landmark-branch sentence missing; figure missing.
- `content/technical/chapter_intro.tex`: stale old copy, not input anywhere; delete.
- Header comments in Literature, Clinical and Technical files still point to `thesis/…` paths and
  old file names (`clinical_background/05_hemodynamics.tex`, `07_daughter_ratio.tex`).
- Frontmatter, abbreviations and Results are template stubs; abbreviations list DSC (unused).
