# Thesis content map (`Thesis_coronary/`)

Read this before writing or editing any thesis text. It records what every chapter and section
already says, what each one leaves to another, and what later parts will say, so that new text
fills exactly its own gap and repeats nothing. Design decisions and writing rules are in the root
`CLAUDE.md` (not repeated here); the `thesis-style` skill holds the voice.

Map last rebuilt on 2026-11-16, for commit b11a997 (GLMM technical background rewritten, appendices
A to D, Introduction to the current design, feature sections 05a to 05c written, FPCA section
shortened, bibliography notes moved to `annotation`). It also catches up on 9ef8902, 73aaea1 and
bde293e, which the previous map (2026-11-09) had not seen. It follows the committed state only.
This file is ignored by git (`.gitignore`: `CLAUDE.md`), so it cannot be part of a commit; update it
on disk right after each commit.

## How to use this map

First, find the section you are writing in the chapter map below and read its "States", "Leaves
to" and "Open" lines. Subsequently, check the defined-once index and the fact-ownership index before
introducing any term, abbreviation, number or study: if it is already owned elsewhere, point back
to it (`Section~\ref{...}`) instead of restating it. Check what the following sections will say,
so nothing is pre-empted.

Keeping the map current: the map describes only **approved** text, and approved means
**committed**. Uncommitted drafts do not change the map. Each time a commit changes files under
`Thesis_coronary/`, update this file to what those committed files now contain: the entry of every
changed section (status, what it states, labels, cite keys, resolved or new open items), the
indexes, the unresolved cross-references, the inconsistency list and the "last rebuilt" date. Update
it on disk right after that commit (the file is ignored by git).
At the start of a writing session, check `git log -- Thesis_coronary/` against the date above and
catch up on any commits the map has not seen.

Status words: **full** = written prose; **notes** = header comments plus one `\todonote`, nothing
written; **stub** = template placeholder text; **empty** = heading only.

## Thesis spine

The question: is coronary geometry on a plaque-free baseline CCTA associated with who develops
plaque about 10 years later, beyond the established (SCORE2) risk factors, in the Herlev–Østerbro
(CGPS) serial cohort? Framing since 2026-11-15 (root `CLAUDE.md`): a prognostic factor study, not a
risk model and not causal.

The argument runs: CAD is the leading cause of death and plaque collects where WSS is low, which
geometry determines (Introduction) → studies tie geometry to WSS, measure it inconsistently, and
never in a random, plaque-free population with follow-up (Literature Review) → anatomy, CAD,
the WSS mechanism and CCTA (Clinical Background) → the mixed model, the sample-size criteria and
FPCA as general methods (Technical Background) → the CT volumes, visual reads and Medis data
delivered (Data) → tracer, Medis check, cohort and outcome, segments, model, budget, features,
measurement properties, FPCA (Methodology) → Results, Discussion, Conclusion (not written).

Chapter order (`main.tex`): Frontmatter → 1 Introduction → 2 Literature Review → 3 Clinical
Background → 4 Technical Background (input from `content/background.tex`, after Clinical) →
5 Data → 6 Methodology → 7 Results → 8 Discussion → 9 Conclusion → Appendix A Placement of the
Bifurcation Point → B Choice of Link Function → C Details of the Mixed Model → D Recalibration of
SCORE2 → AI declaration.
Note that the Literature Review comes **before** the Clinical Background, so the review is the
first place many terms meet the reader (see the defined-once index).

Chapter-wide rules already set by the files: no forward references in the Introduction, the
Literature Review or the Clinical Background (user, 2026-10-05); no opening paragraph or roadmap in
the Clinical and Technical Background (they start at their first section); Technical Background
holds only general methods in the present tense, every setting belongs in the Methodology.
`\clarify{...}` (red note for an open question) and `\todonote{...}` are defined once in
`setup/macros.tex`; the `\providecommand{\clarify}` lines in section files are skipped.
Audit notes on sources go in the `annotation` field of `refs.bib`, never in `note` (a `note` is
printed in the bibliography).

---

## Frontmatter (`content/frontmatter/`)

- `abstract.tex` — **stub** ("Write the abstract here"). Write last.
- `preface.tex` — **stub** with [placeholders] for description, department, dates, programme.
- `acknowledgements.tex` — **stub**; also holds a placeholder "AI-Assisted Work Disclosure" that
  duplicates the appendix `aideclaration.tex`.
- `abbreviations.tex` — **stub list**: AI, CAD, CCTA, CT, DSC. DSC is a template leftover (no Dice
  anywhere); LM, LAD, LCx, RCA, PDA, PLA, WSS, SIS, SSS, ECG, HDL, GLMM, FPCA, SCORE2 are missing.

## 1 Introduction (`content/introduction.tex`, `ch:introduction`) — full, current design

Rewritten to the current design (committed 2026-11-16). States, paragraph by paragraph:
1. CVD is the leading cause of death, 19.2 million deaths in 2023; CAD nearly half
   (stark2025gbd). CAD = plaque in coronary walls; narrows, can rupture → clot → heart attack
   (libby2019atherosclerosis).
2. Plaque is uneven along the tree although risk factors reach every segment; it collects where
   wall shear stress (named here in words, "drag of the blood flow") is low or oscillating
   (chatzizisis2007ess); low mainly on the outer wall after a bifurcation and the inner wall of a
   bend (asakura1990flow); geometry can be measured from an image, shear cannot.
3. Geometry varies between individuals (temov2016bifurcation), so predisposition may depend on
   anatomy; standard risk assessment rests only on systemic factors; SCORE2 is built from age, sex,
   smoking, blood pressure, cholesterol (score2_2021).
4. Whether geometry is associated with developing plaque beyond these factors is unknown: geometry
   defined inconsistently (cui2017bifurcation, kashyap2022tortuosity); mostly measured in referred
   patients with plaque already present, so disease may have altered the geometry (han2022plaque).
5. Aim and design: test whether geometry measured before plaque is visible is associated with
   developing plaque beyond the established risk factors. CGPS random population sample, CCTA for
   research (fuchs2023cgps), a longitudinal subset rescanned about 10 years later. Centerline and
   lumen of the three main arteries from an in-house tracer; **four features**: curvature, lumen
   narrowing along the artery (taper), the LM bifurcation angle, the diameter difference between
   the two daughter arteries. One regression model relates plaque development per segment to the
   features and risk factors, all segments of a person analysed together; the association is tested
   once by comparing with the model without geometry; how much geometry adds to prediction is a
   secondary estimate.
6. Closing: an association would mean that anatomy carries information the risk factors do not; it
   would not show cause, since the analysis adjusts only for these factors; no association would
   suggest geometry from CCTA adds little.

Defines in prose: CAD, CGPS, CCTA. Does not use the words "prognostic factor" (term open with the
supervisor). Evidence cut from here is still owed to the Literature Review (Temov 196 patients and
35.5–178° LM angle; Glagov 136 hearts, ~40% before narrowing).

## 2 Literature Review (`content/litterature_review.tex` → `litterature_review/`, `ch:literature`)

Rebuilt 2026-11-07 (`reports/Literature review table and gaps.md`), revised in the commits of
2026-11-11 to 2026-11-16: section titles changed, the synthesis is now four features.

`00_chapter_intro.tex` — chapter heading only, **no opening paragraph**. Header comment holds the
chapter rules (author and year as subject, `\cite` after the year, cohort sizes only in the table,
no concept explanations, no em dashes, `shen2026geometry` never cited, CAD and CCTA assumed defined
in the Introduction) and which sources were read only as abstracts (lee2024radiomics,
good2026scapis, hageman2023score2: direction only). TODO: search statement.

`01_geometry_wss.tex` — §Geometric Determinants of Low Wall Shear Stress (`sec:lit-wss`), full.
Premise: shape affects WSS, plaque where WSS is low (chatzizisis2007ess) — **defines the
abbreviation WSS** here. WSS cannot be measured directly in the coronary arteries (gijsen2019wss),
so studies simulate flow. Kashyap 2022 (LM bifurcation, CAD-free; average curvature the strongest,
weak but significant correlate of low WSS; tortuosity index unrelated). Zhang 2024 (whole left
tree; curvature, bifurcation angle and Finet's ratio compared, only average curvature higher in
stenosed trees). Garcha and Grande Gutiérrez 2025 (synthetic trees; greater LAD/LCx asymmetry
enlarges the low-WSS area and makes angle and bending matter more) — **defines LAD and LCx** here.
Lumen taper introduced here; Johnston and Johnston (johnston2007diameter, johnston2008sshaped,
johnston2009taper): width matters more than curvature in a few RCAs; in idealised S-shaped models
taper and curvature lower WSS in different places (complementary), not shown in real arteries.
Synthesis: **four** features most tied to low WSS: average curvature, lumen taper, daughter
asymmetry, bifurcation angle. No longer cites asakura1990flow or vandergiessen2009bifurcation.

`02_quantifying_geometry.tex` — §Quantification of Coronary Curvature (`sec:lit-measure`), full.
Any single summary keeps only part of a profile (ramsay2005fda); no agreed coronary curvature
summary (grisan2008tortuosity, kashyap2022tortuosity, li2011tortuosity, telloayala2026tortuosity);
summary choice decided the direction of the association with CAD (Li 2011 bend count, less CAD;
Tello Ayala 2026 average turning angle, more CAD, tortuosity index slightly less). Whole-profile
analysis elsewhere: **FPCA abbreviation first defined here** (ramsay2005fda); Sangalli 2009
(carotid curvature profile separated aneurysm location); Goldsmith 2011 (white-matter tracts,
profile beat average for multiple sclerosis); Tello Ayala 2026 (network on the profile beat the
mean). Closes: the profile shape may hold information a single value discards. Typo to fix:
"decided the the direction".

`03_geometry_risk.tex` — §Longitudinal Prediction of Incident Coronary Plaque (`sec:lit-risk`),
full + table `tab:literature`. Glagov 1987 (arteries enlarge with plaque: geometry could be a
consequence); most geometry studies found in the review were in diseased patients (li2011tortuosity,
zhang2024curvature, han2022plaque, tommasino2024clap, telloayala2026tortuosity); need geometry on
a plaque-free scan and a repeat scan. Won 2022 PARADIGM and Lee 2024 (plaque-free referred
patients, repeat CCTA, no geometry); clinical referral selection. Random population cohorts:
Bergström 2021 SCAPIS (one scan), Good 2026 (repeat-scan design only). Added value is hard:
Hageman 2023 (CAC raised SCORE2's C-index by 0.020, 95% CI 0.012 to 0.028). Geometry studies
covered only part of the tree (LM bifurcation, left tree or RCA). **Gap stated once here**: no
study identified related geometry of all three main arteries on a plaque-free scan to plaque at a
repeat scan in a random population cohort. Table: Tommasino 2024, Tello Ayala 2026, Won 2022, Lee
2024, Bergström 2021 with design and finding. The section title uses "Incident Coronary Plaque"
before its formal definition in `sec:method-population`.

Leaves to others: the WSS mechanism (Clinical Background `sec:wss`); FPCA as a method (Technical
`sec:tech-fpca`); measure definitions (Methods).

## 3 Clinical Background (`content/background.tex` → `background/`, `ch:clinical`)

`chapter_intro.tex` — heading only. Header comment still says the outcome is "new plaque in a
healthy tree" and lists figures to upload (`wss_schematic.pdf`, `rq_curvature.pdf`).

`heart_anatomy.tex` — §The coronary circulation (`sec:circulation`), full. States: four chambers
(RA, LA, RV, LV), two pumps in series, aorta; myocardium supplied by coronary arteries from the aorta
above the aortic valve; **defines ostium, proximal, distal**. Figures `fig:heart-chambers`,
`fig:coronary-arteries` (one float).
- §§The coronary arterial tree (`sec:tree`): LM → LAD (anterior interventricular groove) and LCX
  (left AV groove); diagonals from the LAD, obtuse marginals from the LCX; RCA (right AV groove) →
  PDA and PLA. Defines LM, LAD, LCX, RCA, PDA, PLA (again, after the review).
- §§Coronary dominance (`sec:dominance`): crux; right/left/codominant; right 87–96%
  (ihdayhid2021ethnic); proximal RCA 3.9 vs 2.8 mm and LCX 3.4 vs 4.2 mm by dominance
  (dodge1992diameter). Ends: "every population statistic in this thesis is stratified by dominance"
  — conflicts with the model, where dominance is a base-model term; reconcile.

`disease_and_risk.tex` — §Coronary artery disease (`sec:disease`), full. Defines CAD (again),
atherosclerosis, plaque, endothelium, lumen, ischemia, thrombus, myocardial infarction. Two
mechanisms: gradual narrowing → ischemia (duncker2015regulation); cap rupture → thrombus
(libby2019atherosclerosis, rampidis2022geometry). Figure `fig:atherosclerosis`. No risk factors
and no calcium score despite the file name.

`wall_shear_stress.tex` — §Wall shear stress and plaque formation (`sec:wss`), full. Defines WSS
(again) and oscillatory WSS; plaque where WSS is low (chatzizisis2007ess, samady2011wss,
yamamoto2017ess); oscillation often co-located (chatzizisis2007ess) but its added effect not
established (peiffer2013wss; softened 2026-11-07, never add OSI as a second pathway for a feature);
high WSS harmful only to existing narrowing plaque. Endothelium
mechanism: nitric oxide vs leaky, inflamed (chiu2011disturbed, davies2009shear). Bend: symmetric
profile in a straight tube, inertia carries fast blood outward, low WSS on the inner wall
(ku1997blood, dean1927curved, qiu2000compliant: inner wall about half the outer); defines disturbed
flow. Bifurcation: flow divider (high WSS, spared) vs lateral walls (disturbed); extent set by the
side-branch flow share (antoniadis2015bifurcation, zarins1983carotid, asakura1990flow,
vandergiessen2009bifurcation, nakazawa2010pathological). References `fig:wss-sites`, which does not
exist. No thresholds in Pa, no Poiseuille/R³ law (cut 2026-10-07); taper's WSS ∝ 1/r³ rationale is
owned by Methods `05d_taper`. Header: griffo2026wss must never be upgraded to "predicts plaque".

`ccta.tex` — §Coronary CT angiography (`sec:ccta`), full but ends abruptly after the voxel
sentence. Defines CCTA (again), contrast agent, ECG gating, mid-diastole reconstruction, heart-rate
lowering, voxel (knuuti2019esc, abbara2016scct). Header says resolution claims and "our 0.5 mm
grid" were added, but they are not in the text: the resolution part is missing or was cut.

## 4 Technical Background (`content/technical/`, `ch:technical`)

`00_chapter_intro.tex` — heading only; header lists sections and the rule (general methods only).
Added predictive value (C, calibration, Brier, log loss, internal validation) is **deliberately not
written**; drafts in `outdated/thesis_retired/technical_background/03*.tex` and git `e4eb857`.
Input order (`content/background.tex`): 01_mixed_model, 01b_sample_size, 02_fpca.

`01_mixed_model.tex` — §Generalised Linear Mixed Model (`sec:tech-model`), **full**, rewritten
2026-11-15/16 around the hazard ratio and the test of a set of covariates (file renamed from
`01_prediction_model.tex`). The dated edit log is in
`research_notes/Mixed model study note/01_mixed_model_changelog.md`; a plain-language study note
(`mixed_model_explainer.tex`, not thesis text) sits beside it. Units and clusters only, no cohort.
- Opener: linear regression → GLM (dobson2002glm 3.4); Bernoulli outcome with probability $p_i$,
  **defines risk**; **linear predictor** (`eq:tech-lp`); **link function** $g$, whose inverse maps
  the linear predictor to a risk (`eq:tech-link`; dobson 3.4, 7.2).
- §§The Complementary Log-Log Link and the Hazard Ratio (`sec:tech-segment-glmm`): cloglog link
  (dobson 7.3) arises from the **hazard**; **cumulative hazard** Λ, no event = exp(−Λ) (dobson
  10.2, Eq. 10.4); **proportional hazards** as the condition (Eq. 10.8); intercept holds the
  baseline cumulative hazard; risk $1-\exp\{-\exp(\eta)\}$ (`eq:tech-cloglog`,
  prentice1978grouped pp. 58–59, **unverified, CHECK**). **Hazard ratio** exp(β_k) (Eq. 10.7),
  **adjusted**, read per unit of its covariate. **Exposure** $E_i$ as γ log E; γ = 1 is an
  **offset** (dobson 9.2), γ estimated otherwise.
- §§Clustered Outcomes and the Random Intercept (`sec:tech-random-intercept`): GLM independence
  fails for clusters; inference from a model ignoring the correlation is not valid (dobson 11.1);
  **GLMM**, random intercept $b_i \sim N(0,\sigma^2)$ (`eq:tech-glmm`; from here $i$ = cluster,
  $j$ = unit); **fixed effects, random effect, mixed model** (dobson 11.5). **Frailty** exp(b_i)
  and the **median hazard ratio (MHR)** as the median ratio between two units with the same
  covariates from two random clusters (austin2017mhr 2.2). Conditional reading: exp(β_k) compares
  units with the same frailty, within a cluster for a unit-level covariate, between clusters of
  equal frailty for a cluster-level covariate (uncited, from the equation).
- §§Likelihood Ratio Test and Cluster Risk (`sec:tech-glmm-likelihood`): maximum likelihood, the
  likelihood averaged over the random intercepts (→ `app:glmm-fitting`); LR test of a set of $q$
  covariates (`eq:tech-lr`; dobson 5.7, 11.7), reference distribution assumes the random effects
  capture the within-cluster dependence; a second random effect for a subgroup (→
  `app:glmm-variance`; CHECK, keep only if Methods 03 uses an artery-level effect). Anchor
  `sec:tech-aggregation`: cluster risk of at least one event; units independent given $b_i$;
  hazards add to $H_i$ (`eq:tech-agg-conditional`); averaged over $b_i$ for a new cluster (→
  `app:glmm-risk`); hazard closer: one unit is one of $n_i$ terms of $H_i$, so a clear association
  in `eq:tech-lr` may change the cluster risk only slightly.
- Notation taken: $p_i, \eta_i, \beta_k, x_{ik}, g, \Lambda_i, E_i, \gamma, b_i, \sigma^2,
  p_{ij}, \eta_{ij}, \Lambda_{ij}, H_i, n_i, A_i, \ell_0, \ell_1, q$. Says "set", not "block".
- No longer in this section: recalibration (moved to Methods `sec:method-recalibration`), the
  95% interval (Methods 03 must name it), the standard-error between/within rule (CITATION
  WANTED), the pointer to Appendix B (owed by Methods 03), averaged vs conditional hazard ratios
  and the causal caveat (Discussion).

`01b_sample_size.tex` — §Sample Size for Prediction Models (`sec:tech-sample-size`), **full**.
Riley criteria for a binary outcome (riley2020samplesize): shrinkage S ≥ 0.9, optimism in
Nagelkerke R² ≤ 0.05, outcome proportion within ±0.05; the first limits the parameters;
$P_{\max}$ (`eq:tech-pmax`); Cox–Snell R² from the anticipated C-statistic (riley2021cstat, **not
in `refs.bib`**); `pmsampsize` with a `\clarify` (citation and version). Title and prose say
"prediction model", which the prognostic factor framing has not revisited.

`02_fpca.tex` — §Functional Principal Component Analysis (`sec:tech-fpca`), **full**, shortened to
one section without subsections (the long header keeps the history). Opener: FPCA for functional
data, **defines curve, component and score**; re-expands "FPCA" (first defined in
`sec:lit-measure`). Anchor `sec:tech-fpca-components`: common domain t ∈ [0,1], $x_i(t)$, mean
$\mu(t)$, deviations (`fig:tech-fpca-mean`); covariance broken into shapes, **eigenfunctions**
$\phi_k$ and **eigenvalues** $\lambda_k$, found one at a time (`fig:tech-fpca-steps`); reading a
score; Karhunen–Loève truncation (`eq:tech-fpca-kl`), optimal for given K; **mode of variation**
(`eq:tech-fpca-mode`, `fig:tech-fpca-modes`); names are readings, not tested; sign arbitrary, fixed
by a convention. Anchor `sec:tech-fpca-k`: **FVE**; threshold is ad hoc; stability of the shapes
over random subsamples as the guide for K (song2018stability). Cites wang2016fda,
jones1992displaying, hershjmpfpca (the JMP guide, now cited five times), song2018stability;
**hershjmpfpca and song2018stability are not in `refs.bib`**. Removed since the last map: the
subsections and labels `sec:tech-fpca-scores`, `-reading`, `-grid`, `-registration`, the equations
`eq:tech-fpca-cov`, `-eigen`, `-score`, `-fve`, `-grid`, the figures `fig:tech-fpca-curves`, `-cov`,
`-rebuild`, `-phase` (their PDFs are still in `figures/`, unused), grid computation and
registration. Methods 07 notes still plan to point back to `sec:tech-fpca-grid` and
`sec:tech-fpca-registration`, which no longer exist.

## 5 Data (`content/data.tex` → `data/`, `ch:data`)

`00_chapter_intro.tex` — opening paragraph + `tab:data-overview`, full. Three data sets: baseline CT
volumes (→ tracer and features; [n] scans), visual analysis at baseline and follow-up (→ cohort and
outcome; 1,801), Medis centerlines and contours (→ tracer reference; 600 / [n]). Defines CCTA again
(and SIS, SSS only in the table).

`01_ct_volumes.tex` — §Study Population and CT Volumes (`sec:data-cohort`), full. CGPS described
("referred to in this thesis as Herlev–Østerbro"), random from the Danish Civil Registration System;
1,801 participants, median follow-up [..] years (IQR [..]); non-contrast ECG-gated calcium scan +
CCTA at each visit; only baseline CCTA analysed; follow-up used through its visual read. Open:
volume count, scanner, kV, contrast, voxel size, kernel. Leaves cohort criteria to
`sec:method-population`.

`02_visual_analysis.tex` — §Visual Analysis and Patient Characteristics (`sec:data-plaque-location`),
full. All BL and FU scans read; per segment of 17: stenosis grade (none, minimal, mild, moderate,
severe, occlusion), plaque type, high-risk features, evaluability; **defines SIS and SSS**; unread
segments filled with none, separate read flag, all 1,801 BL scans read. SCORE2 factors recorded at
both visits (score2_2021). Open: who read the scans and how. The label name is historical (no plaque
location here; that moved to `sec:results-cohort`).

`03_medis_reference.tex` — §Medis Centerlines and Contours (`sec:data-medis`), full. 600 centerline
trees labelled by segment; 3,049 lumen and outer-wall contour segments, plaque segments only; all
600 linked in BL and FU; 599 with plaque at baseline, fewer than five plaque-free; 599 of 724 with
plaque have a tree (82.7%); 120 of the other 125 flagged finished, so likely lost in delivery;
similar plaque location, extent and worst grade. Open: how made, selection criterion, contour scan
count, completeness of LAD/LCx/RCA. Leaves all use of Medis to `sec:method-medis`.

## 6 Methodology (`content/methods.tex` → `methodology/`, `ch:methodology`)

`00_chapter_intro.tex` — full: nine-stage numbered opener (the one allowed inline list) pointing to
`fig:method-overview` (figure not made, `\clarify`). Stages: (1) tracer, (2) Medis comparison,
(3) cohort and outcome, (4) segments, (5) the statistical model relating the features to the
outcome, and its cross-validation, (6) parameter budget and feature choice, (7) features,
(8) measurement properties, (9) FPCA. Keep it in step with the sections below.

`01a_inhouse_tracker.tex` — §Coronary Centerline and Lumen Extraction (`sec:method-tracer`), full
but minimal: tracer applied to all baseline scans, developed and run by Kit Mills Bransby, described
only to show the pipeline. `\clarify` with an `enumerate` (question for Kit: description, name).
The question whether centerlines are smoothed before output is not in it; `05a_curvature` depends
on it.

`01b_medis_reference.tex` — §Medis Reference as validation for the in house tracer output
(`sec:method-medis`), full. No ground truth → indirect estimate against Medis centerlines and
semi-manual contours; outside the plaque-free cohort; Medis labels by segment, tracer by artery →
Medis proximal/mid/distal collapsed into one full artery; only LAD, LCx, RCA. The centerlines and
contours enter "the model" only through the features (wording changed from "prediction model").
- §§Agreement Between the Tracer and Medis (`sec:method-medis-agreement`): agreement on features,
  not points; tracer mapped into Medis coordinates, paired by participant and label; centerline
  features on the full artery, lumen features only between the first and last Medis contour
  (schaap2009cat08, **not in `refs.bib`**). Open: how Medis data were made; coordinate frames.
  Limitations (single reader, plaque-only reference, shared imaging errors) belong in the
  Discussion.

`02_population_outcome.tex` — §Study Cohort and Outcome (`sec:method-population`), full. Cohort =
SIS 0 at baseline, minus insufficient image quality ([criterion]); **defines incident coronary
plaque** (segment: minimal or worse; participant: plaque in ≥1 analysed segment); sensitivity
outcome mild or worse. `\clarify`: the outcome could still change. Counts go to
`sec:results-cohort`. Does not repeat the Data chapter.

`02b_segment_split.tex` — §Analysed Arteries and Segments (**no label**), full.
- §§Choice of Arteries (`sec:method-population-arteries`): LAD, LCx, RCA for outcome and features;
  present in every heart (side branches vary with dominance, `sec:dominance`); voxel-error argument
  with [..] blanks (dodge1992diameter); LM left out (the review relates the LM angle to disease at
  the start of the LAD and LCx); plaque only in LM or a side branch counted as no outcome;
  discussion section on this misclassification owed (`Section~[..]`).
- §§Division into Segments (`sec:method-split`): WSS is local → features at the outcome's
  resolution; proximal/mid/distal → nine segments (`fig:method-segments`, figure missing); landmark
  method, fixed fraction where no branch; full rules in `sec:app-split` (appendix not in the
  submission). The sentence naming the landmark branches is missing ("no such branch").
- §§Validation of the Division (`sec:method-split-validation`): Medis contours projected onto the
  divided tracer artery; majority segment not graded plaque at baseline = miss; miss rate in
  `sec:results-cohort`; per-segment features preferred despite the boundary uncertainty.

`03_prediction_model.tex` — §Statistical Model and Evaluation (`sec:method-models`), **partly
written**. Two prose sentences: the cloglog link is used so that the hazards of the nine segments
add to one participant hazard (→ `sec:tech-aggregation`), and since plaque is seen only at
follow-up the coefficients are hazard ratios over the window (→ `sec:tech-segment-glmm`,
prentice1978grouped pp. 58–59, CHECK). Then one `\todonote` for the model itself.
- §§Recalibration of SCORE2 (`sec:method-recalibration`), full: recalibration of a published score
  on the cloglog scale with intercept α and slope δ (`eq:method-recal`); calibration in the large;
  reading of δ as 2^δ; SCORE2 is itself built and regionally recalibrated on this scale
  (score2_2021, → `app:score2-recal`); recalibration keeps the relative weights, so a new covariate
  can appear informative by correcting a weight. Written as general method in the present tense;
  since 2026-11-15 the recalibrated score is only a sensitivity analysis (root `CLAUDE.md`), so its
  place and length need revisiting. CITATION WANTED: a general recalibration source.
- §§Cross-Validation (`sec:method-cv`), notes.
- Header notes hold the plan (pooled cloglog GLMM, base with six refitted risk factors, extended
  model with four features, LR test of the geometry block as the main result, hazard ratios per SD
  with 95% CI, secondary ΔC and calibration, back-to-back risk histograms, the open random-effects
  structure) and the **appendix pointers this section owes**: Appendix B (`app:link`) where the
  link is chosen, the MHR formula (`eq:tech-mhr`), `app:glmm-fitting` where the quadrature is
  named, and the decision on the artery-level random effect. Settings come from
  `CGPS_data/progression_who_pooled.py`, not yet in `thesis_final/`.

`04_model_size.tex` — §Parameter Budget and Feature Selection (`sec:method-size`), §§Parameter
Budget (`sec:method-size-budget`), §§Selection of Geometric Features (`sec:method-selection`),
**notes** (three `\todonote`s; the last names "the four retained features"). Relies on
`sec:tech-sample-size`.

`05_features.tex` — §Geometric Features (`sec:method-features`), **full** intro + table
`tab:method-features`. Four features chosen on a prior hypothesis (bends, branching, narrowing
lower WSS, `sec:wss`); the measure for each is the one most tied to low WSS or plaque in the review
(`sec:lit-wss`). Curvature and taper per segment (nine); bifurcation angle and daughter asymmetry
once per participant at the LM bifurcation, entering the model only in the proximal LAD and
proximal LCx (→ `sec:method-models`). All from the tracer (`sec:method-tracer`). Inputs:
- `05a_curvature.tex` §§Curvature (`sec:method-curvature`), **full**. **Defines curvature as the
  inverse radius** of the circle through three points, by Menger's formula (menger1930metrik,
  **not in `refs.bib`**; `eq:method-profile`): points 5 mm behind and ahead of each centerline
  point (scale after vanzandwijk2019curvature); curvature profile along the whole artery, no value
  within about 5 mm of the ends, then divided at the segment boundaries; segment average $T$
  (`eq:method-tl`), the average absolute curvature recommended by kashyap2022tortuosity; fewer than
  two profile points = missing; profile shape → `sec:method-fpca`. Figure `fig:method-curvature`.
  §§§Other Measures of Tortuosity (`sec:method-curvature-other`): defines tortuosity as the general
  word; tortuosity index, bend counts (li2011tortuosity, telloayala2026tortuosity, →
  `sec:lit-measure`) and torsion (`\clarify` citation) not used. CHECK against code: the caption
  says "computed with the thesis code", while `CGPS_data/thesis_final/turning_feature.py` is
  deleted in the working tree; confirm which module computes Menger curvature.
- `05b_bifurcation_angle.tex` §§Bifurcation Angle (`sec:method-angle`), **full**. LAD–LCx angle in
  3D after medranogracia2016atlas: bifurcation point $O$ = last shared centerline point; points
  every 0.5 mm between 5 and 10 mm; least-squares line per artery; `eq:method-angle`; missing when
  no shared point or an artery shorter than 10 mm; → `app:angle-origin`. Figure `fig:method-angle`.
  §§§Other Angles at the Bifurcation (`sec:method-angle-other`): LM–LAD and LM–LCx angles not used
  (cui2017bifurcation), inflow angle not used (zhang2024curvature).
- `05c_daughter_ratio.tex` §§Daughter Asymmetry (`sec:method-ratio`), **full**. Area-equivalent
  diameter $D$ (`eq:method-diameter`, medranogracia2016atlas); one diameter per vessel as the
  median of $D$ over 5 to 10 mm from $O$ (adapted from gharleghi2025sex); asymmetry
  $a = \ln(D_{LCx}/D_{LAD})$ (`eq:method-asymmetry`); missing rules; prespecified angle ×
  asymmetry interaction → `sec:method-models`. Figure `fig:method-ratio`. No scaling-law exponents
  (Murray, 2.39, 7/3) in the text any more.
- `05d_taper.tex` §§Lumen Taper (`sec:method-taper`), **notes** (rationale and Theil–Sen estimate
  from the lumen cross-sections). Must point back to the taper paragraphs of `sec:lit-wss`.
- Not thesis text, in the same folder: `bifurcation_plan.md`, `daugther_ration_plan.md`, figure
  scripts in `figures/` (colours from `setup/figure_colours.py`, run by `make_figures.py`).

`06_feature_validity.tex` — §Measurement Properties of the Geometric Features
(`sec:method-validity`), **notes**, with empty subsections §§Technical Accuracy on Synthetic Shapes
(`sec:method-validity-accuracy`), §§Definitional Choices (`sec:method-validity-definitions`,
`sec:method-validity-sensitivity`), §§Construct Validity (`sec:method-validity-groups`,
`sec:method-validity-evidence`), §§Variance Explained by Known Risk Factors
(`sec:method-validity-split`), §§Decision Rules (`sec:method-validity-reading`). Medis deliberately
not part of it.

`07_curvature_fpca.tex` — §Secondary Analysis of Curvature Shape (`sec:method-fpca`), **notes**:
FPCA of the curvature profile in the proximal and mid LAD, descriptive. The `\todonote` still says
"turning-angle profile", while `05a` now defines the profile by Menger curvature. Header notes:
50-point grid, respacing, segment ends as landmarks, K rule, per-segment descriptive cloglog with a
1 df risk-factor summary (open, root `CLAUDE.md`). Relies on `sec:tech-fpca`, which no longer has
grid or registration subsections, so those general parts now have no home.

## 7 Results (`content/results.tex`, `ch:results`)

Titled "Experiments and Results". Only `results/baseline.tex`: §Baseline segmentation
(`sec:baseline`), **stub** from the template ("week 7 figure goes here"); unrelated to this thesis.
Expected sections referenced from elsewhere: `sec:results-cohort` (cohort flowchart, counts, where
incident plaque developed, segment-division miss rate); `results/01_feature_validity` (from 06 notes).

## 8 Discussion (`content/discussion.tex`, `ch:discussion`) — one sentence

Headings §Limitations, §Future work. §Limitations holds one sentence: random slopes were not
considered, as "three of the five features" are constant within a participant and nine binary
outcomes do not identify a slope variance (the count conflicts with the four features of
`sec:method-features`, two of which are constant within a participant). Already promised to the
chapter: misclassification of LM/side-branch-only plaque (02b); Medis limitations (01b);
repeatability not assessable (`sec:disc-validity-repeatability`, 06 notes); proportional hazards
untestable with one follow-up scan, conditional versus averaged hazard ratios and the causal caveat
(Technical 01, Methods 03); the single person intercept if no artery-level effect is fitted.

## 9 Conclusion (`content/conclusion.tex`, `ch:conclusion`) — empty

## Appendix

Order in `main.tex`: A, B, C, D, then the AI declaration.

`appendix/bifurcation_point.tex` — A Placement of the Bifurcation Point (`app:angle-origin`), full.
$O$ can only be placed approximately; lines from $O$ tilt with a misplaced $O$
(`tab:app-angle-tilt`), fitted lines over 5 to 10 mm do not (`tab:app-angle-offset`); cost: a bend
in that stretch enters the angle (medranogracia2016atlas). Pointed to by `sec:method-angle`.

`appendix/link_choice.tex` — B Choice of Link Function (`app:link`), full. §Derivation of the
Complementary Log-Log Link (`app:link-derivation`: 0.99^10 example, `eq:app-link-ph`,
`eq:app-link-cloglog`; dobson2002glm, prentice1978grouped CHECK). §Comparison with the Logit Link
(`app:link-logit`: odds ratio, only one of the two ratios constant over time, `fig:app-link`,
1.51 vs 1.73 example, rates add and odds do not, risk tied to the fitted window, neither
assumption testable with one observation). **No pointer in running text** since 2026-11-16; owed
by Methods 03.

`appendix/mixed_model_details.tex` — C Details of the Mixed Model (`app:glmm`), full. §Fitting by
Quadrature (`app:glmm-fitting`: adaptive Gauss–Hermite, Laplace; liu1994gausshermite,
pinheiro1995approximations, joe2008laplace, statacorp2025mecloglog). §The Variance of the Random
Intercept (`app:glmm-variance`: MHR formula `eq:tech-mhr`, austin2017mhr; σ² poorly estimated,
moineddin2007multilevel, austin2010clusters; anchor `sec:tech-nested`: second random effect, halved
p-value, self1987boundary, stram1994variance). §The Marginal Cluster Risk (`app:glmm-risk`:
`eq:tech-agg-marginal`; b = 0 risk miscalibrated, pavlou2015marginal, skrondal2009prediction).

`appendix/score2_recalibration.tex` — D Recalibration of SCORE2 (`app:score2-recal`), full. Worked
example of the SCORE2 supplement (50-year-old male smoker, low-risk region): LP 0.3221,
uncalibrated risk 0.0541, scale1 −0.5699, scale2 0.7476, calibrated risk 0.0631
(`tab:app-score2-recal`, score2_2021); reading of the slope (2^0.7476 = 1.68). Pointed to by
`sec:method-recalibration`.

`aideclaration.tex` — "Use of generative AI", full (one paragraph). Expected but missing:
`sec:app-split` (segment division details) and `sec:app-validity` (feature validity details).

---

## Defined-once index (where each term is first defined, in reading order)

| Term | First defined | Also (re)defined in — remove or turn into a pointer |
|---|---|---|
| CAD | Introduction ¶1 | Clinical `sec:disease` |
| CCTA | Introduction ¶5 | Clinical `sec:ccta`; Data chapter intro |
| CGPS / Herlev–Østerbro | Introduction ¶5 (CGPS) | Data `sec:data-cohort` (both names) |
| Wall shear stress | Introduction ¶2 (in words) | Lit `sec:lit-wss` (abbrev. WSS); Clinical `sec:wss` |
| LAD, LCx | Lit `sec:lit-wss` (Garcha) | Clinical `sec:tree` (as LCX); Methods 02b |
| Lumen taper | Lit `sec:lit-wss` (Johnston) | — |
| Daughter asymmetry | Lit `sec:lit-wss` (in words) | Methods `sec:method-ratio` (formula) |
| LM, RCA, PDA, PLA | Clinical `sec:tree` | Methods 02b (LM, RCA again) |
| Ostium, proximal, distal | Clinical `sec:circulation` | — |
| Dominance, crux | Clinical `sec:dominance` | — |
| Plaque, endothelium, lumen, ischemia, thrombus, MI | Clinical `sec:disease` | — |
| Oscillatory WSS, disturbed flow, flow divider, lateral wall | Clinical `sec:wss` | — |
| Voxel, ECG gating | Clinical `sec:ccta` | ECG again in Data `sec:data-cohort` |
| FPCA (abbreviation) | Lit `sec:lit-measure` | Technical `sec:tech-fpca` (expanded again) |
| GLM, risk, linear predictor, link function | Technical `sec:tech-model` | — |
| Cloglog link, hazard, cumulative hazard, proportional hazards, hazard ratio, adjusted, exposure, offset | Technical `sec:tech-segment-glmm` | Appendix `app:link-derivation` (derivation) |
| GLMM, random intercept, fixed and random effects, frailty, MHR | Technical `sec:tech-random-intercept` | Appendix `app:glmm-variance` (MHR formula) |
| Likelihood ratio test, cluster risk | Technical `sec:tech-glmm-likelihood` | — |
| Shrinkage, $P_{\max}$, Cox–Snell R² | Technical `sec:tech-sample-size` | — |
| Curve, component, score, eigenfunction, FVE, mode of variation | Technical `sec:tech-fpca` | — |
| SIS, SSS, stenosis grades | Data `sec:data-plaque-location` | Data intro table |
| SCORE2 factors | Introduction ¶3 (in words) | Data `sec:data-plaque-location` |
| Incident coronary plaque | Methods `sec:method-population` | used earlier in the title of `sec:lit-risk` |
| Artery vs segment | Methods `sec:method-split` | — |
| Curvature (inverse radius), curvature profile, average curvature $T$, tortuosity | Methods `sec:method-curvature` | — |
| Bifurcation point $O$, bifurcation angle | Methods `sec:method-angle` | — |
| Area-equivalent diameter | Methods `sec:method-ratio` | — |
| Recalibration, calibration in the large | Methods `sec:method-recalibration` | Appendix `app:score2-recal` (worked example) |

Spelling clash: the Introduction, Literature Review, Data and Methods write **LCx**; the Clinical
Background still writes **LCX**. Unit/cluster (Technical) correspond to segment/participant
(Methods); the Methods must say so once.

## Fact ownership (state once, point back elsewhere)

- 19.2 million CVD deaths, CAD nearly half → Introduction.
- Right dominance 87–96%; RCA/LCX diameters by dominance → `sec:dominance`.
- 1,801 participants; all BL scans read → Data (`sec:data-cohort`, `sec:data-plaque-location`).
- Follow-up interval (median, IQR) → `sec:data-cohort` (blank).
- 600 Medis trees, 3,049 contours, 599/724 (82.7%), 120 of 125 finished → `sec:data-medis`.
- Clean-cohort size, image-quality exclusions, events, plaque per artery, 93.6% (452/483) of those
  who developed plaque have it in LAD/LCx/RCA, segment miss rate → `sec:results-cohort` (not written).
- Outcome definition and sensitivity outcome → `sec:method-population`.
- Kashyap: average curvature most related to low WSS, weak → Literature (`sec:lit-wss`); Methods
  05a cites it only for the recommended average absolute curvature and the tortuosity index.
- The four features as the ones most tied to low WSS → end of `sec:lit-wss`; Methods 05 points back.
- The research gap → end of `sec:lit-risk` only.
- WSS mechanism (endothelium, bend, bifurcation) → `sec:wss`.
- Cloglog link, hazard ratio, offset, random intercept, frailty, MHR, LR test, cluster risk and the
  dilution of one unit in the cluster hazard → `sec:tech-model` (general); derivation and logit
  comparison → Appendix B; quadrature, MHR formula, nested effect, marginal risk → Appendix C.
- Riley criteria and $P_{\max}$ → `sec:tech-sample-size`; the numbers (S, C, budget) → Methods 04.
- Recalibration of a score on the cloglog scale → `sec:method-recalibration`; the SCORE2 worked
  example (0.0541 → 0.0631) → Appendix D.
- 5 mm chord scale for curvature (van Zandwijk) and Menger's formula → `sec:method-curvature`.
- 5 to 10 mm stretch for the bifurcation angle and the daughter diameters (Medrano-Gracia) →
  `sec:method-angle`; why the angle does not depend on $O$ → Appendix A.
- LM angle and asymmetry enter only the proximal LAD and proximal LCx rows → `sec:method-features`.
- WSS ∝ 1/r³ for taper and the normal taper size → Methods 05d (notes only).
- FPCA definitions, modes of variation, choice of K by stability → `sec:tech-fpca`; settings,
  respacing and segment-end landmarks → Methods 07 (notes). Grid computation and registration are
  currently owned by no section.
- Taper and curvature lower WSS at different sites (Johnston models) → `sec:lit-wss`; Methods 05d
  points back.
- Summary choice flips the direction of the curvature–CAD association → `sec:lit-measure`.
- CAC adds 0.020 to SCORE2's C-index (Hageman 2023) → `sec:lit-risk`.
- Oscillatory WSS not established as an added effect → `sec:wss`.
- Tracer authorship (Kit Mills Bransby) → `sec:method-tracer`.

## Citation map (cite key → where cited)

Cited in more than one chapter: asakura1990flow (Intro, Clinical WSS); chatzizisis2007ess (Intro,
Lit 01, Clinical WSS); cui2017bifurcation (Intro, Methods 05b); dodge1992diameter (Clinical
dominance, Methods 02b); han2022plaque (Intro, Lit 03); kashyap2022tortuosity (Intro, Lit 01, 02,
03, Methods 05a); li2011tortuosity and telloayala2026tortuosity (Lit 02, 03, Methods 05a);
zhang2024curvature (Lit 01, 03, Methods 05b); libby2019atherosclerosis (Intro, Clinical CAD);
score2_2021 (Intro, Data 02, Methods 03, Appendix D); dobson2002glm (Technical 01, Appendix B);
prentice1978grouped (Technical 01, Methods 03, Appendix B; **unverified, PDF wanted in
`papers/`**); austin2017mhr (Technical 01, Appendix C); medranogracia2016atlas (Methods 05b, 05c,
Appendix A).

Single chapter only — Introduction: stark2025gbd, temov2016bifurcation, fuchs2023cgps. Literature:
bergstrom2021scapis, garcha2025sensitivity, gijsen2019wss, glagov1987remodeling, goldsmith2011pfr,
good2026scapis, grisan2008tortuosity, hageman2023score2, johnston2007diameter, johnston2008sshaped,
johnston2009taper, lee2024radiomics, ramsay2005fda, sangalli2009aneurisk, tommasino2024clap,
won2022paradigm. Clinical: shah2009heart, weinhaus2024anatomy, devos2024coronary,
obrien2007anatomy, allwork1987applied, ihdayhid2021ethnic, duncker2015regulation,
rampidis2022geometry, samady2011wss, yamamoto2017ess, peiffer2013wss, bajraktari2021highwss,
davies2009shear, chiu2011disturbed, ku1997blood, dean1927curved, qiu2000compliant,
zarins1983carotid, antoniadis2015bifurcation, nakazawa2010pathological,
vandergiessen2009bifurcation, knuuti2019esc, abbara2016scct. Technical: riley2020samplesize,
riley2021cstat, wang2016fda, jones1992displaying, hershjmpfpca, song2018stability. Methods:
schaap2009cat08, vanzandwijk2019curvature, menger1930metrik, gharleghi2025sex. Appendix:
liu1994gausshermite, pinheiro1995approximations, joe2008laplace, statacorp2025mecloglog,
moineddin2007multilevel, austin2010clusters, self1987boundary, stram1994variance,
pavlou2015marginal, skrondal2009prediction.

**Cited but missing from `refs.bib`** (undefined in the build of 2026-11-16): riley2021cstat,
hershjmpfpca, song2018stability, schaap2009cat08, menger1930metrik.

Rules from the files: every study the Introduction cites must be discussed in the Literature
Review — temov2016bifurcation and cui2017bifurcation are cited in the Introduction but not in the
review. Never cite shen2026geometry. Studies from the review return in the Methods only as
citations inside a reason. Audit notes live in the `annotation` field of `refs.bib`. Notes-only
Methods files will add, among others: malek1999shear, taylor2024murray, huo2012scaling,
finet2008fractal, mokkink2010cosmin, kessler2015qib, raunig2015qib, lakens2017equivalence,
seiler1992structure, schultz2023ess, theil1950rank, sen1968estimates; check each is in `refs.bib`
and open the source before use (root `CLAUDE.md`, citation rules of 2026-11-16).

## Cross-references not yet resolved

- `fig:method-overview` (Methods 00) — overview figure not made.
- `fig:method-segments` (Methods 02b) — the figure exists in
  `outdated/thesis_retired/methodology/02b_segment_split.tex` and `segment_selection_schematic.pdf`
  but was not taken over.
- `fig:wss-sites` (Clinical WSS) — no figure; header mentions a Shen 2026 crop, but Shen is never to
  be cited.
- `sec:app-split` (Methods 02b) — appendix not in the submission.
- `sec:results-cohort` (Methods 02, 02b; Data 02 comment) — Results section not written.
- Methods 02b's `Section~[..]` for the misclassification discussion.
- Five undefined citations (see the citation map).
- Planned in notes but without a target: `sec:tech-fpca-grid`, `sec:tech-fpca-registration`
  (Methods 07), `sec:tech-added-value` (Methods 03), `sec:disc-validity-repeatability` (Methods 06).
- Appendix B (`app:link`) and `eq:tech-mhr` are not referenced from running text.

## Known inconsistencies to resolve (listed, not fixed)

- Feature count: the Introduction, `sec:lit-wss` and `sec:method-features` say four features
  (daughter asymmetry as one term); the Discussion sentence says "three of the five features"; the
  geometry line of the root `CLAUDE.md` still lists the LM→LAD and LM→LCx ratios separately.
- Curvature naming: `05a` defines Menger curvature; the `\todonote` of Methods 07 and older notes
  say "turning-angle profile"; `CGPS_data/thesis_final/turning_feature.py` is deleted in the
  working tree. Confirm the module the Methods text must match.
- "Prediction model" wording after the prognostic factor framing: title and prose of
  `sec:tech-sample-size`; file name `03_prediction_model.tex`; `sec:lit-risk` title "Longitudinal
  Prediction ...". "Block" (Methods 03 `\todonote`, root `CLAUDE.md`) vs "set" (Technical 01).
- `sec:method-recalibration` is general method written in the present tense inside the Methodology,
  for what is now only a sensitivity analysis.
- `sec:tech-fpca` lost its grid and registration parts; Methods 07 notes still rely on them. Four
  FPCA figure PDFs are unused. The JMP guide (hershjmpfpca) is cited, where the earlier rule was
  "style only, not cited".
- prentice1978grouped is cited in three places and has not been opened in a verifiable way.
- "new plaque" in the Clinical chapter's header comment.
- `sec:lit-measure`: typo "the the direction". `sec:lit-risk`: "However most" lacks a comma.
- FPCA is expanded twice (`sec:lit-measure`, `sec:tech-fpca`).
- Dominance: "every population statistic … stratified by dominance" (`sec:dominance`) vs dominance
  as a possible base-model covariate (Methods 03 notes; open in the root `CLAUDE.md`).
- `ccta.tex` ends mid-section; the resolution paragraph its header describes is missing.
- `01a_inhouse_tracker.tex`: `enumerate` inside `\clarify`; smoothing question missing.
- `01b_medis_reference.tex`: section title not in the style of the others; a bold **proximal**; a
  stray `Medis: \clarify{...}` line with an unclosed bracket in its text.
- `02b_segment_split.tex`: section has no label; landmark-branch sentence missing; figure missing.
- `content/technical/chapter_intro.tex`: stale old copy, not input anywhere; delete.
- Header comments in Literature, Clinical and Technical files still point to `thesis/…` paths and
  old file names.
- Frontmatter, abbreviations and Results are template stubs; abbreviations list DSC (unused) and
  lack GLM, GLMM, MHR, FVE among others.
- Build files (`main.aux`, `main.bbl`, `content/*.aux` and similar) and two stray PDFs
  (`curvature_compare.pdf`, `curvature_section.pdf`) sit untracked in `Thesis_coronary/`.
